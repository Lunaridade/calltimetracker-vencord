/*
 * Vencord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Plugin: CallTimeTracker
 * Descrição: Lê mensagens de sistema de DMs e soma o tempo total de chamadas com cada amigo.
 */

import { NavContextMenuPatchCallback } from "@api/ContextMenu";
import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { findByPropsLazy } from "@webpack";
import {
    ChannelStore,
    GuildStore,
    Menu,
    MessageStore,
    React,
    RelationshipStore,
    RestAPI,
    SelectedChannelStore,
    UserStore,
} from "@webpack/common";
import { User } from "discord-types/general";

// ────────────────────────────────────────────────────────────
// Tipos
// ────────────────────────────────────────────────────────────

interface CallMessage {
    id: string;
    type: number;       // 3 = call
    call?: {
        duration?: number; // segundos
        ended_timestamp?: string;
    };
    content: string;    // fallback: "Lunar iniciou uma chamada que durou 10 minutos"
    timestamp: string;
}

interface CallStats {
    totalSeconds: number;
    callCount: number;
    missedCalls: number;
    oldestMessageDate: string | null;
    newestMessageDate: string | null;
}

// ────────────────────────────────────────────────────────────
// Settings
// ────────────────────────────────────────────────────────────

const settings = definePluginSettings({
    startYear: {
        type: OptionType.NUMBER,
        description: "Ano a partir do qual contar as chamadas (ex: 2024)",
        default: 2024,
    },
    showInProfile: {
        type: OptionType.BOOLEAN,
        description: "Mostrar tempo de chamada no perfil do usuário",
        default: true,
    },
    showMissedCalls: {
        type: OptionType.BOOLEAN,
        description: "Mostrar contagem de chamadas perdidas",
        default: true,
    },
});

// ────────────────────────────────────────────────────────────
// Helpers de parsing
// ────────────────────────────────────────────────────────────

/**
 * Tenta extrair duração em segundos de mensagens de sistema do Discord.
 * Suporta português e inglês.
 *
 * Exemplos:
 *   "Lunar iniciou uma chamada que durou 10 minutos."
 *   "Lunar started a call that lasted 1 hour and 30 minutes."
 *   "You started a call that lasted 45 seconds."
 *   "Chamada durou 2 horas."
 */
function parseDurationFromContent(content: string): number | null {
    if (!content) return null;

    let totalSeconds = 0;
    let found = false;

    // Horas
    const hoursMatch = content.match(/(\d+)\s*(?:hora[s]?|hour[s]?)/i);
    if (hoursMatch) {
        totalSeconds += parseInt(hoursMatch[1], 10) * 3600;
        found = true;
    }

    // Minutos
    const minutesMatch = content.match(/(\d+)\s*(?:minuto[s]?|minute[s]?|min)/i);
    if (minutesMatch) {
        totalSeconds += parseInt(minutesMatch[1], 10) * 60;
        found = true;
    }

    // Segundos
    const secondsMatch = content.match(/(\d+)\s*(?:segundo[s]?|second[s]?|sec)/i);
    if (secondsMatch) {
        totalSeconds += parseInt(secondsMatch[1], 10);
        found = true;
    }

    return found ? totalSeconds : null;
}

/**
 * Verifica se uma mensagem é do tipo "chamada encerrada" (tipo 3)
 * ou se o conteúdo indica uma chamada de sistema.
 */
function isCallMessage(msg: CallMessage): boolean {
    // Tipo 3 = mensagem de chamada no Discord
    if (msg.type === 3) return true;

    // Fallback por conteúdo (para casos onde a API retorna tipo diferente)
    if (!msg.content) return false;
    const lower = msg.content.toLowerCase();
    return (
        lower.includes("iniciou uma chamada") ||
        lower.includes("started a call") ||
        lower.includes("chamada perdida") ||
        lower.includes("missed call") ||
        lower.includes("durou") ||
        lower.includes("lasted")
    );
}

function isMissedCall(msg: CallMessage): boolean {
    if (!msg.content) return false;
    const lower = msg.content.toLowerCase();
    return (
        lower.includes("chamada perdida") ||
        lower.includes("missed call") ||
        lower.includes("sem resposta") ||
        lower.includes("no answer")
    );
}

// ────────────────────────────────────────────────────────────
// Busca de mensagens via REST API
// ────────────────────────────────────────────────────────────

async function fetchAllMessages(channelId: string, startDate: Date): Promise<CallMessage[]> {
    const allMessages: CallMessage[] = [];
    let before: string | undefined;
    let keepGoing = true;
    const startTimestamp = startDate.getTime();

    while (keepGoing) {
        const params: Record<string, string> = { limit: "100" };
        if (before) params.before = before;

        try {
            const response = await RestAPI.get({
                url: `/channels/${channelId}/messages`,
                query: params,
            });

            const messages: CallMessage[] = response.body;

            if (!messages || messages.length === 0) {
                keepGoing = false;
                break;
            }

            for (const msg of messages) {
                const msgTime = new Date(msg.timestamp).getTime();

                if (msgTime < startTimestamp) {
                    // Mensagem mais antiga que o filtro — para a busca
                    keepGoing = false;
                    break;
                }

                if (isCallMessage(msg)) {
                    allMessages.push(msg);
                }
            }

            // Próxima página: antes da mensagem mais antiga do lote
            before = messages[messages.length - 1].id;

            // Rate limit gentil
            await new Promise(r => setTimeout(r, 300));

        } catch (err) {
            console.error("[CallTimeTracker] Erro ao buscar mensagens:", err);
            keepGoing = false;
        }
    }

    return allMessages;
}

// ────────────────────────────────────────────────────────────
// Processamento de estatísticas
// ────────────────────────────────────────────────────────────

async function getCallStats(userId: string): Promise<CallStats> {
    const dmChannel = Object.values(ChannelStore.getSortedPrivateChannels()).find(
        (ch: any) => ch.type === 1 && ch.recipients?.includes(userId)
    ) as any;

    if (!dmChannel) {
        return { totalSeconds: 0, callCount: 0, missedCalls: 0, oldestMessageDate: null, newestMessageDate: null };
    }

    const startDate = new Date(`${settings.store.startYear}-01-01T00:00:00.000Z`);
    const messages = await fetchAllMessages(dmChannel.id, startDate);

    let totalSeconds = 0;
    let callCount = 0;
    let missedCalls = 0;
    let oldestDate: string | null = null;
    let newestDate: string | null = null;

    for (const msg of messages) {
        // Atualiza datas
        if (!oldestDate || msg.timestamp < oldestDate) oldestDate = msg.timestamp;
        if (!newestDate || msg.timestamp > newestDate) newestDate = msg.timestamp;

        // Verifica chamada perdida
        if (isMissedCall(msg)) {
            missedCalls++;
            continue;
        }

        // Tenta pegar duração pelo objeto call (mais preciso)
        if (msg.call?.duration) {
            totalSeconds += msg.call.duration;
            callCount++;
            continue;
        }

        // Fallback: parse do conteúdo textual
        const parsed = parseDurationFromContent(msg.content);
        if (parsed !== null && parsed > 0) {
            totalSeconds += parsed;
            callCount++;
        }
    }

    return { totalSeconds, callCount, missedCalls, oldestMessageDate: oldestDate, newestMessageDate: newestDate };
}

// ────────────────────────────────────────────────────────────
// Formatação de tempo
// ────────────────────────────────────────────────────────────

function formatDuration(totalSeconds: number): string {
    if (totalSeconds === 0) return "Nenhuma chamada registrada";

    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const parts: string[] = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (seconds > 0 && days === 0) parts.push(`${seconds}s`); // só mostra segundos se < 1 dia

    return parts.join(" ");
}

function formatDate(isoString: string | null): string {
    if (!isoString) return "—";
    return new Date(isoString).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
    });
}

// ────────────────────────────────────────────────────────────
// Componente React para o Modal
// ────────────────────────────────────────────────────────────

interface CallStatsModalProps {
    user: User;
    onClose: () => void;
}

function CallStatsModal({ user, onClose }: CallStatsModalProps) {
    const [stats, setStats] = React.useState<CallStats | null>(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState<string | null>(null);

    React.useEffect(() => {
        getCallStats(user.id)
            .then(s => {
                setStats(s);
                setLoading(false);
            })
            .catch(e => {
                setError("Erro ao carregar estatísticas.");
                setLoading(false);
            });
    }, [user.id]);

    const avatarUrl = `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`;

    return (
        <div style={styles.overlay} onClick={onClose}>
            <div style={styles.modal} onClick={e => e.stopPropagation()}>
                {/* Header */}
                <div style={styles.header}>
                    <img
                        src={avatarUrl}
                        alt="avatar"
                        style={styles.avatar}
                        onError={(e: any) => { e.target.src = `https://cdn.discordapp.com/embed/avatars/${parseInt(user.discriminator) % 5}.png`; }}
                    />
                    <div>
                        <div style={styles.username}>{user.globalName || user.username}</div>
                        <div style={styles.subtitle}>Histórico de Chamadas</div>
                    </div>
                    <button style={styles.closeBtn} onClick={onClose}>✕</button>
                </div>

                <div style={styles.divider} />

                {/* Conteúdo */}
                {loading && (
                    <div style={styles.loadingContainer}>
                        <div style={styles.spinner} />
                        <span style={styles.loadingText}>Lendo histórico de mensagens...</span>
                        <span style={styles.loadingSubtext}>Isso pode levar alguns segundos</span>
                    </div>
                )}

                {error && (
                    <div style={styles.errorBox}>
                        <span style={{ fontSize: "24px" }}>⚠️</span>
                        <span>{error}</span>
                    </div>
                )}

                {stats && !loading && (
                    <div style={styles.statsContainer}>
                        {/* Tempo total — destaque */}
                        <div style={styles.mainStat}>
                            <div style={styles.mainStatLabel}>⏱ Tempo Total em Chamadas</div>
                            <div style={styles.mainStatValue}>{formatDuration(stats.totalSeconds)}</div>
                            <div style={styles.mainStatYear}>desde {settings.store.startYear}</div>
                        </div>

                        {/* Grid de estatísticas secundárias */}
                        <div style={styles.statsGrid}>
                            <StatCard
                                icon="📞"
                                label="Chamadas"
                                value={String(stats.callCount)}
                            />
                            {settings.store.showMissedCalls && (
                                <StatCard
                                    icon="📵"
                                    label="Perdidas"
                                    value={String(stats.missedCalls)}
                                />
                            )}
                            <StatCard
                                icon="📅"
                                label="Primeira"
                                value={formatDate(stats.oldestMessageDate)}
                            />
                            <StatCard
                                icon="🕐"
                                label="Última"
                                value={formatDate(stats.newestMessageDate)}
                            />
                        </div>

                        {/* Média por chamada */}
                        {stats.callCount > 0 && (
                            <div style={styles.averageBox}>
                                <span style={styles.averageLabel}>Média por chamada:</span>
                                <span style={styles.averageValue}>
                                    {formatDuration(Math.floor(stats.totalSeconds / stats.callCount))}
                                </span>
                            </div>
                        )}

                        {stats.totalSeconds === 0 && (
                            <div style={styles.emptyState}>
                                Nenhuma chamada encontrada desde {settings.store.startYear}.<br />
                                <span style={{ fontSize: "12px", opacity: 0.6 }}>
                                    Apenas chamadas em DM são suportadas.
                                </span>
                            </div>
                        )}
                    </div>
                )}

                <div style={styles.footer}>
                    Dados lidos das mensagens de sistema da DM • CallTimeTracker
                </div>
            </div>
        </div>
    );
}

function StatCard({ icon, label, value }: { icon: string; label: string; value: string }) {
    return (
        <div style={styles.statCard}>
            <div style={styles.statIcon}>{icon}</div>
            <div style={styles.statValue}>{value}</div>
            <div style={styles.statLabel}>{label}</div>
        </div>
    );
}

// ────────────────────────────────────────────────────────────
// Estilos
// ────────────────────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
    overlay: {
        position: "fixed",
        inset: 0,
        background: "rgba(0, 0, 0, 0.75)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9999,
        backdropFilter: "blur(4px)",
    },
    modal: {
        background: "var(--background-primary, #313338)",
        borderRadius: "16px",
        width: "420px",
        maxWidth: "95vw",
        boxShadow: "0 24px 64px rgba(0,0,0,0.5)",
        overflow: "hidden",
        border: "1px solid var(--background-modifier-accent, #3f4147)",
    },
    header: {
        display: "flex",
        alignItems: "center",
        gap: "14px",
        padding: "20px 20px 16px",
        position: "relative" as const,
    },
    avatar: {
        width: "52px",
        height: "52px",
        borderRadius: "50%",
        flexShrink: 0,
    },
    username: {
        color: "var(--header-primary, #f2f3f5)",
        fontSize: "18px",
        fontWeight: 700,
        lineHeight: 1.2,
    },
    subtitle: {
        color: "var(--text-muted, #949ba4)",
        fontSize: "13px",
        marginTop: "2px",
    },
    closeBtn: {
        position: "absolute" as const,
        right: "16px",
        top: "16px",
        background: "transparent",
        border: "none",
        color: "var(--text-muted, #949ba4)",
        fontSize: "16px",
        cursor: "pointer",
        padding: "4px 8px",
        borderRadius: "4px",
        lineHeight: 1,
    },
    divider: {
        height: "1px",
        background: "var(--background-modifier-accent, #3f4147)",
        margin: "0 20px",
    },
    loadingContainer: {
        display: "flex",
        flexDirection: "column" as const,
        alignItems: "center",
        gap: "10px",
        padding: "40px 20px",
        color: "var(--text-normal, #dbdee1)",
    },
    spinner: {
        width: "36px",
        height: "36px",
        border: "3px solid var(--background-modifier-accent, #3f4147)",
        borderTop: "3px solid var(--brand-500, #5865f2)",
        borderRadius: "50%",
        animation: "spin 0.8s linear infinite",
    },
    loadingText: {
        fontSize: "15px",
        fontWeight: 500,
        color: "var(--header-primary, #f2f3f5)",
    },
    loadingSubtext: {
        fontSize: "12px",
        color: "var(--text-muted, #949ba4)",
    },
    errorBox: {
        display: "flex",
        flexDirection: "column" as const,
        alignItems: "center",
        gap: "10px",
        padding: "32px",
        color: "var(--status-danger, #f23f43)",
        textAlign: "center" as const,
    },
    statsContainer: {
        padding: "20px",
        display: "flex",
        flexDirection: "column" as const,
        gap: "16px",
    },
    mainStat: {
        background: "var(--background-secondary, #2b2d31)",
        borderRadius: "12px",
        padding: "20px",
        textAlign: "center" as const,
        border: "1px solid var(--background-modifier-accent, #3f4147)",
    },
    mainStatLabel: {
        fontSize: "12px",
        color: "var(--text-muted, #949ba4)",
        textTransform: "uppercase" as const,
        letterSpacing: "0.08em",
        fontWeight: 600,
        marginBottom: "6px",
    },
    mainStatValue: {
        fontSize: "32px",
        fontWeight: 800,
        color: "var(--brand-500, #5865f2)",
        lineHeight: 1.1,
        letterSpacing: "-0.02em",
    },
    mainStatYear: {
        fontSize: "12px",
        color: "var(--text-muted, #949ba4)",
        marginTop: "4px",
    },
    statsGrid: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "10px",
    },
    statCard: {
        background: "var(--background-secondary, #2b2d31)",
        borderRadius: "10px",
        padding: "14px",
        textAlign: "center" as const,
        border: "1px solid var(--background-modifier-accent, #3f4147)",
    },
    statIcon: {
        fontSize: "20px",
        marginBottom: "6px",
    },
    statValue: {
        fontSize: "16px",
        fontWeight: 700,
        color: "var(--header-primary, #f2f3f5)",
        marginBottom: "2px",
    },
    statLabel: {
        fontSize: "11px",
        color: "var(--text-muted, #949ba4)",
        textTransform: "uppercase" as const,
        letterSpacing: "0.06em",
        fontWeight: 600,
    },
    averageBox: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        background: "var(--background-secondary, #2b2d31)",
        borderRadius: "10px",
        padding: "12px 16px",
        border: "1px solid var(--background-modifier-accent, #3f4147)",
    },
    averageLabel: {
        fontSize: "13px",
        color: "var(--text-muted, #949ba4)",
    },
    averageValue: {
        fontSize: "14px",
        fontWeight: 700,
        color: "var(--header-primary, #f2f3f5)",
    },
    emptyState: {
        textAlign: "center" as const,
        color: "var(--text-muted, #949ba4)",
        fontSize: "14px",
        lineHeight: 1.6,
        padding: "10px 0",
    },
    footer: {
        padding: "12px 20px",
        fontSize: "11px",
        color: "var(--text-muted, #949ba4)",
        textAlign: "center" as const,
        background: "var(--background-secondary, #2b2d31)",
        borderTop: "1px solid var(--background-modifier-accent, #3f4147)",
    },
};

// ────────────────────────────────────────────────────────────
// Injeção no Context Menu do perfil de usuário
// ────────────────────────────────────────────────────────────

let modalRoot: HTMLDivElement | null = null;

function openCallStatsModal(user: User) {
    // Remove modal anterior se existir
    if (modalRoot) {
        modalRoot.remove();
        modalRoot = null;
    }

    modalRoot = document.createElement("div");
    modalRoot.id = "call-time-tracker-modal";
    document.body.appendChild(modalRoot);

    // Adiciona keyframe de spinner via style tag
    if (!document.getElementById("ctt-spinner-style")) {
        const style = document.createElement("style");
        style.id = "ctt-spinner-style";
        style.textContent = `
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }

    const { createRoot } = require("react-dom/client");
    const root = createRoot(modalRoot);
    root.render(
        React.createElement(CallStatsModal, {
            user,
            onClose: () => {
                root.unmount();
                modalRoot?.remove();
                modalRoot = null;
            },
        })
    );
}

// ────────────────────────────────────────────────────────────
// Context Menu Patch
// ────────────────────────────────────────────────────────────

const userContextMenuPatch: NavContextMenuPatchCallback = (children, { user }: { user?: User; }) => {
    if (!user || user.id === UserStore.getCurrentUser()?.id) return;

    // Adiciona item no menu de contexto do usuário
    children.push(
        React.createElement(Menu.MenuSeparator, { key: "ctt-sep" }),
        React.createElement(
            Menu.MenuItem,
            {
                id: "ctt-view-call-time",
                key: "ctt-view-call-time",
                label: "⏱ Ver Tempo de Chamadas",
                action: () => openCallStatsModal(user),
            }
        )
    );
};

// ────────────────────────────────────────────────────────────
// Definição do Plugin
// ────────────────────────────────────────────────────────────

export default definePlugin({
    name: "CallTimeTracker",
    description: "Mostra o tempo total de chamadas em DMs com um usuário, lendo as mensagens de sistema do histórico de conversa.",
    authors: [
        {
            id: 0n,
            name: "você",
        },
    ],
    settings,

    contextMenus: {
        "user-context": userContextMenuPatch,
        "user-profile-actions": userContextMenuPatch,
    },

    start() {
        console.log("[CallTimeTracker] Plugin iniciado!");
    },

    stop() {
        // Remove modal se estiver aberto
        if (modalRoot) {
            modalRoot.remove();
            modalRoot = null;
        }
        // Remove estilo do spinner
        document.getElementById("ctt-spinner-style")?.remove();
        console.log("[CallTimeTracker] Plugin parado.");
    },
});
